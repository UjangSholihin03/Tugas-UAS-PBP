// task-service.js
import { validate } from "../validation/validation.js";
import {
  createTaskValidation,
  getTaskValidation,
  updateTaskValidation,
  removeTaskValidation,
  searchTaskValidation,
} from "../validation/task-validation.js";
import { prismaClient } from "../application/database.js";
import { ResponseError } from "../error/response-error.js";

const createTask = async (user, taskData) => {
  const task = validate(createTaskValidation, taskData); // Fix: Use createTaskValidation instead of taskValidation
  task.username = user.username;

  return prismaClient.task.create({
    data: task,
    select: {
      id: true,
      title: true,
      description: true,
      due_date: true,
      task_status: true,
      task_type: true,
      task_repeat: true,
    },
  });
};

const getTask = async (user, taskId) => {
  taskId = validate(getTaskValidation, taskId); // Fix: Use getTaskValidation instead of taskValidation

  const task = await prismaClient.task.findFirst({
    where: {
      username: user.username,
      id: taskId,
    },
    select: {
      id: true,
      title: true,
      description: true,
      due_date: true,
      task_status: true,
      task_type: true,
      task_repeat: true,
    },
  });

  if (!task) {
    throw new ResponseError(404, "Task is not found");
  }

  return task;
};

const updateTask = async (user, taskData) => {
  const task = validate(updateTaskValidation, taskData); // Fix: Use updateTaskValidation instead of taskValidation

  const totalTasksInDatabase = await prismaClient.task.count({
    where: {
      username: user.username,
      id: task.id,
    },
  });

  if (totalTasksInDatabase !== 1) {
    throw new ResponseError(404, "Task is not found");
  }

  return prismaClient.task.update({
    where: {
      id: task.id,
    },
    data: {
      title: task.title,
      description: task.description,
      due_date: task.due_date,
      task_status: task.task_status,
      task_type: task.task_type,
      task_repeat: task.task_repeat,
    },
    select: {
      id: true,
      title: true,
      description: true,
      due_date: true,
      task_status: true,
      task_type: true,
      task_repeat: true,
    },
  });
};

const removeTask = async (user, taskId) => {
  taskId = validate(removeTaskValidation, taskId); // Fix: Use removeTaskValidation instead of taskValidation

  const totalInDatabase = await prismaClient.task.count({
    where: {
      username: user.username,
      id: taskId,
    },
  });

  if (totalInDatabase !== 1) {
    throw new ResponseError(404, "Task is not found");
  }

  return prismaClient.task.delete({
    where: {
      id: taskId,
    },
  });
};

const searchTasks = async (user, request) => {
  request = validate(searchTaskValidation, request); // Fix: Use searchTaskValidation instead of taskValidation

  const skip = (request.page - 1) * request.size;

  const filters = [
    {
      username: user.username,
    },
  ];

  if (request.title) {
    filters.push({
      title: {
        contains: request.title,
      },
    });
  }

  if (request.description) {
    filters.push({
      description: {
        contains: request.description,
      },
    });
  }

  if (request.due_date) {
    filters.push({
      due_date: {
        contains: request.due_date,
      },
    });
  }

  if (request.task_status) {
    filters.push({
      task_status: {
        contains: request.task_status,
      },
    });
  }

  if (request.task_type) {
    filters.push({
      task_type: {
        contains: request.task_type,
      },
    });
  }

  if (request.task_repeat) {
    filters.push({
      task_repeat: {
        contains: request.task_repeat,
      },
    });
  }

  // Add similar conditions for other search criteria

  const tasks = await prismaClient.task.findMany({
    where: {
      AND: filters,
    },
    take: request.size,
    skip: skip,
  });

  const totalItems = await prismaClient.task.count({
    where: {
      AND: filters,
    },
  });

  return {
    data: tasks,
    paging: {
      page: request.page,
      total_item: totalItems,
      total_page: Math.ceil(totalItems / request.size),
    },
  };
};

export default {
  createTask,
  getTask,
  updateTask,
  removeTask,
  searchTasks,
};
