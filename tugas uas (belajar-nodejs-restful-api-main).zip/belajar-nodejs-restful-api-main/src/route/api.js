import express from "express";
import userController from "../controller/user-controller.js";
import taskController from "../controller/task-controller.js";
import { authMiddleware } from "../middleware/auth-middleware.js";

const userRouter = express.Router(); // Perubahan: Menggunakan express.Router() daripada new express.Router()

userRouter.use(authMiddleware);

// API Pengguna (User)
userRouter.get("/api/users/current", userController.get);
userRouter.patch("/api/users/current", userController.update);
userRouter.delete("/api/users/logout", userController.logout);

// API Tugas (Task) (Perbaikan: Menggunakan taskController daripada contactController)
userRouter.post("/api/tasks", taskController.create);
userRouter.get("/api/tasks/:taskId", taskController.get);
userRouter.put("/api/tasks/:taskId", taskController.update);
userRouter.delete("/api/tasks/:taskId", taskController.remove);
userRouter.get("/api/tasks", taskController.search);

export { userRouter };
