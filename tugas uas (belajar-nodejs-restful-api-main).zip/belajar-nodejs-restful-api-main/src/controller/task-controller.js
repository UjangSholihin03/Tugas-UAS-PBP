import taskService from "../service/task-service.js";
import { logger } from "../application/logging.js";

const create = async (req, res, next) => {
  try {
    const user = req.user;
    const requestData = req.body;
    const taskData = {
      title: requestData.title,
      description: requestData.description,
      due_date: requestData.due_date,
      task_status: requestData.task_status,
      task_type: requestData.task_type,
      task_repeat: requestData.task_repeat,
    };

    const result = await taskService.createTask(user, taskData);
    res.status(200).json({
      data: result,
    });
  } catch (e) {
    next(e);
  }
};

const remove = async (req, res, next) => {
  try {
    const user = req.user;
    const taskId = req.params.taskId;

    await taskService.removeTask(user, taskId);
    res.status(200).json({
      data: "OK",
    });
  } catch (e) {
    next(e);
  }
};

const get = async (req, res, next) => {
  try {
    const user = req.user;
    const taskId = req.params.taskId;

    const result = await taskService.getTask(user, taskId);

    res.status(200).json({
      data: result,
    });
  } catch (e) {
    next(e);
  }
};

const update = async (req, res, next) => {
  try {
    // Implementasi fungsi update
    const user = req.user;
    const taskId = req.params.taskId;
    const requestData = req.body;
    requestData.id = taskId;

    const updatedTask = await taskService.updateTask(user, requestData);

    res.status(200).json({
      data: updatedTask,
    });
  } catch (e) {
    next(e);
  }
};

const search = async (req, res, next) => {
  try {
    // Implementasi fungsi search
    const user = req.user;
    const query = req.query;

    const searchResults = await taskService.searchTasks(user, query);

    res.status(200).json({
      data: searchResults.data,
      paging: searchResults.paging,
    });
  } catch (e) {
    next(e);
  }
};

export default {
  create,
  get,
  update,
  remove,
  search,
};
