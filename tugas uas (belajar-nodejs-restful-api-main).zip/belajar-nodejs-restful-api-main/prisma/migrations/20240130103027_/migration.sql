-- AlterTable
ALTER TABLE `tasks` MODIFY `due_date` VARCHAR(191) NOT NULL;
