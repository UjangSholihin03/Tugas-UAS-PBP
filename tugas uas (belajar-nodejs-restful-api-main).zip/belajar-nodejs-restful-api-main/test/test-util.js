import { prismaClient } from "../src/application/database.js";
import bcrypt from "bcrypt";

export const removeTestUser = async () => {
  await prismaClient.user.deleteMany({
    where: {
      username: "test",
    },
  });
};

export const createTestUser = async () => {
  await prismaClient.user.create({
    data: {
      username: "test",
      password: await bcrypt.hash("rahasia", 10),
      name: "test",
      token: "test",
    },
  });
};

export const getTestUser = async () => {
  return prismaClient.user.findUnique({
    where: {
      username: "test",
    },
  });
};

export const removeAllTestTasks = async () => {
  await prismaClient.task.deleteMany({
    where: {
      username: "test",
    },
  });
};

export const createTestTask = async () => {
  await prismaClient.task.create({
    data: {
      title: "pergi ke pasar",
      description: "membeli bahan bahan dapur",
      due_date: "19-10-2000",
      task_status: "on going",
      task_type: "priority",
      task_repeat: "weekly",
      username: "test",
    },
  });
};

export const createManyTestTasks = async () => {
  for (let i = 0; i < 15; i++) {
    await prismaClient.task.create({
      data: {
        username: `test`,
        title: `test${i}`,
        description: `test${i}`,
        due_date: `test${i}`,
        task_status: `test${i}`,
        task_type: `test${i}`,
        task_repeat: `test${i}`,
      },
    });
  }
};

export const getTestTask = async () => {
  return prismaClient.task.findFirst({
    where: {
      username: "test",
    },
  });
};

// export const createTestTaskWithDetails = async () => {
//   const testUser = await getTestUser();

//   await prismaClient.task.create({
//     data: {
//       username: testUser.username,
//       title: "pergi ke pasar",
//       description: "membeli bahan bahan dapur",
//       due_date: new Date("2000-10-19"),
//       task_status: "on going",
//       task_type: "priority",
//       task_repeat: "weekly",
//     },
//   });
// };
