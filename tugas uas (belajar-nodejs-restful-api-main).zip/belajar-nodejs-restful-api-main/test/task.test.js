import {
  createManyTestTasks,
  createTestTask,
  createTestUser,
  getTestTask,
  removeAllTestTasks,
  removeTestUser,
} from "./test-util.js";
import supertest from "supertest";
import { web } from "../src/application/web.js";
import { logger } from "../src/application/logging.js";

describe("POST /api/tasks", function () {
  beforeEach(async () => {
    await createTestUser();
  });

  afterEach(async () => {
    await removeAllTestTasks();
    await removeTestUser();
  });

  it("should can create new task", async () => {
    const result = await supertest(web)
      .post("/api/tasks")
      .set("Authorization", "test")
      .send({
        title: "test",
        description: "test",
        due_date: "test",
        task_status: "test",
        task_type: "test",
        task_repeat: "test",
      });

    expect(result.status).toBe(200);
    expect(result.body.data.id).toBeDefined();
    expect(result.body.data.title).toBe("test");
    expect(result.body.data.description).toBe("test");
    expect(result.body.data.due_date).toBe("test");
    expect(result.body.data.task_status).toBe("test");
    expect(result.body.data.task_type).toBe("test");
    expect(result.body.data.task_repeat).toBe("test");
  });

  it("should reject if request is not valid", async () => {
    const result = await supertest(web)
      .post("/api/tasks")
      .set("Authorization", "test")
      .send({
        title: "",
        description: "membeli bahan bahan dapur",
        due_date: "19-10-2000",
        task_status: "on going",
        task_type: "priority",
        task_repeat: "monthly",
      });

    expect(result.status).toBe(400);
    expect(result.body.errors).toBeDefined();
  });
});

describe("GET /api/tasks/:taskId", function () {
  beforeEach(async () => {
    await createTestUser();
    await createTestTask();
  });

  afterEach(async () => {
    await removeAllTestTasks();
    await removeTestUser();
  });

  it("should can get task", async () => {
    const testTask = await getTestTask();

    const result = await supertest(web)
      .get("/api/tasks/" + testTask.id)
      .set("Authorization", "test");

    expect(result.status).toBe(200);
    expect(result.body.data.id).toBe(testTask.id);
    expect(result.body.data.title).toBe(testTask.title);
    expect(result.body.data.description).toBe(testTask.description);
    expect(result.body.data.due_date).toBe(testTask.due_date);
    expect(result.body.data.task_status).toBe(testTask.task_status);
    expect(result.body.data.task_type).toBe(testTask.task_type);
    expect(result.body.data.task_repeat).toBe(testTask.task_repeat);
  });

  it("should return 404 if task id is not found", async () => {
    const testTask = await getTestTask();

    const result = await supertest(web)
      .get("/api/tasks/" + (testTask.id + 1))
      .set("Authorization", "test");

    expect(result.status).toBe(404);
  });
});

describe("PUT /api/tasks/:taskId", function () {
  beforeEach(async () => {
    await createTestUser();
    await createTestTask();
  });

  afterEach(async () => {
    await removeAllTestTasks();
    await removeTestUser();
  });

  it("should can update existing task", async () => {
    const testTask = await getTestTask();

    const result = await supertest(web)
      .put("/api/tasks/" + testTask.id)
      .set("Authorization", "test")
      .send({
        title: "jajan seblak",
        description: "jangan pedes-pedes",
        due_date: "19-10-2003",
        task_status: "on going",
        task_type: "priority",
        task_repeat: "weekly",
      });

    expect(result.status).toBe(200);
    expect(result.body.data.id).toBe(testTask.id);
    expect(result.body.data.title).toBe("jajan seblak");
    expect(result.body.data.description).toBe("jangan pedes-pedes");
    expect(result.body.data.due_date).toBe("19-10-2003");
    expect(result.body.data.task_status).toBe("on going");
    expect(result.body.data.task_type).toBe("priority");
    expect(result.body.data.task_repeat).toBe("weekly");
  });

  it("should reject if request is invalid", async () => {
    const testTask = await getTestTask();

    const result = await supertest(web)
      .put("/api/tasks/" + testTask.id)
      .set("Authorization", "test")
      .send({
        title: "",
        description: "",
        due_date: "19-10-2003",
        task_status: "on going",
        task_type: "",
        task_repeat: "",
      });

    expect(result.status).toBe(400);
    expect(result.body.errors).toBeDefined();
  });

  it("should reject if task is not found", async () => {
    const testTask = await getTestTask();

    const result = await supertest(web)
      .put("/api/tasks/" + (testTask.id + 1))
      .set("Authorization", "test")
      .send({
        title: "jajan seblak",
        description: "jangan pedes-pedes",
        due_date: "19-10-2003",
        task_status: "on going",
        task_type: "priority",
        task_repeat: "weekly",
      });

    expect(result.status).toBe(404);
  });
});

describe("DELETE /api/tasks/:taskId", function () {
  beforeEach(async () => {
    await createTestUser();
    await createTestTask();
  });

  afterEach(async () => {
    await removeAllTestTasks();
    await removeTestUser();
  });

  it("should can delete task", async () => {
    let testTask = await getTestTask();
    const result = await supertest(web)
      .delete("/api/tasks/" + testTask.id)
      .set("Authorization", "test");

    expect(result.status).toBe(200);
    expect(result.body.data).toBe("OK");

    testTask = await getTestTask();
    expect(testTask).toBeNull();
  });

  it("should reject if task is not found", async () => {
    let testTask = await getTestTask();
    const result = await supertest(web)
      .delete("/api/tasks/" + (testTask.id + 1))
      .set("Authorization", "test");

    expect(result.status).toBe(404);
  });
});

describe("GET /api/tasks", function () {
  beforeEach(async () => {
    await createTestUser();
    await createManyTestTasks();
  });

  afterEach(async () => {
    await removeAllTestTasks();
    await removeTestUser();
  });

  it("should can search without parameter", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .set("Authorization", "test");

    logger.info("---------------");
    logger.info(result.body);
    logger.info("---------------");

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(10);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(2);
    expect(result.body.paging.total_item).toBe(15);
  });

  it("should can search to page 2", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        page: 2,
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(5);
    expect(result.body.paging.page).toBe(2);
    expect(result.body.paging.total_page).toBe(2);
    expect(result.body.paging.total_item).toBe(15);
  });

  it("should can search using title", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        title: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });

  it("should can search using description", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        description: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });

  it("should can search using due_date", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        due_date: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });

  it("should can search using task status", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        task_status: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });

  it("should can search using task type", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        task_type: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });

  it("should can search using task repeat", async () => {
    const result = await supertest(web)
      .get("/api/tasks")
      .query({
        task_repeat: "test1",
      })
      .set("Authorization", "test");

    logger.info(result.body);

    expect(result.status).toBe(200);
    expect(result.body.data.length).toBe(6);
    expect(result.body.paging.page).toBe(1);
    expect(result.body.paging.total_page).toBe(1);
    expect(result.body.paging.total_item).toBe(6);
  });
});
